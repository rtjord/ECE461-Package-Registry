import createAssigner from './_createAssigner.js';
import allKeys from './allKeys.js';

// Extend a given object with all the properties in passed-in object(s).
export default createAssigner(allKeys);
