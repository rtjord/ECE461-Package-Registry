import tagTester from './_tagTester.js';

export default tagTester('Symbol');
